﻿using System;

namespace P211_Static
{
    class Program
    {
        static void Main()
        {
            #region Instance vs class members
            //Developer developer = new Developer("Sebuhi", "Web developer");
            //Employee employee = new Employee(15, "Namiq");
            //Employee employee1 = new Employee("Zakir");
            //Person person = new Person("Eli");
            //Person person1 = new Person("Veli");

            //Console.WriteLine(Person.CountOfPeople);
            //Console.WriteLine(Employee.CountOfEmployee);
            //Console.WriteLine(Developer.CountOfDevelopers);

            //sebuhi.Firstname = "Sebuhi";
            //sebuhi.Lastname = "Heziyev";
            //sebuhi.Birthdate = new DateTime(2002, 12, 20);

            //ramiz.Firstname = "Ramiz";
            //ramiz.Lastname = "Esebi";
            //ramiz.Birthdate = new DateTime(2000, 07, 23);
            #endregion

            Person person = new Person("Samir");
            Person person1 = new Person("Aqil");
            Person person2 = new Person("Buhi Sebuhi");
            Person person3 = new Person("Miz Ramiz");


            Console.WriteLine(person.Id);
            Console.WriteLine(person1.Id);
            Console.WriteLine(person2.Id);
            Console.WriteLine(person3.Id);

        }

        static string NumberCorrector(string number)
        {
            return number + 2;
        }
    }

    static class Mathematic
    {
        public static int Add(int a, int b) => a + b;
        public static int Divide(int a, int b) => a / b;
        public static int Multiply(int a, int b) => a * b;
        public static int Subtract(int a, int b) => a - b;
        public static int FindPower(int main, int power) {

            int result = 1;
            for (int i = 0; i < power; i++)
            {
                result *= main;
            }

            return result;
        }
    }

    class Person
    {
        //static constructor - gets called only once by the runtime, can not be invoked by new keyword
        static Person()
        {
            Console.WriteLine("Person class was used for the first time");
            //CountOfPeople = 7_000_000_000; 
            _idCounter = 1000;
        }

        //instance constructor - gets called each time new keyword is called
        public Person(string firstname)
        {
            //CountOfPeople++;
            Firstname = firstname;
            Console.WriteLine("Person instance constructor was called");
            Id = _idCounter++;
        }

        public static int _idCounter;
        public int Id { get; private set; }
        //public static ulong CountOfPeople { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public DateTime Birthdate { get; set; }

        public void TellYourName()
        {
            Console.WriteLine($"{Firstname} {Lastname}");
        }

        public int Add10YearsToAge()
        {
            return DateTime.Now.Year - Birthdate.Year + 10;
        }

        public static int Add10Years(int age)
        {
            return age + 10;
        }
    }

    class Employee : Person
    {
        public Employee(string fname) : base(fname)
        {
            CountOfEmployee++;
            Console.WriteLine("New Employee was born");
        }

        public Employee(int experience, string fname) : this(fname)
        {
        }

        public int Experience { get; set; }

        public static int CountOfEmployee { get; set; }
    }

    class Developer : Employee
    {
        public string Profession { get; set; }

        public Developer(string fname, string profession) : base(fname)
        {
            CountOfDevelopers++;
            Console.WriteLine("Developer was born");
            Profession = profession;
        }

        public static int CountOfDevelopers { get; set; }
    }
}
